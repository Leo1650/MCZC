<?php
session_start();
include("../fu/db_conn.php");

if(isset($_POST['login'])){
    
        $username = $_POST['username'];
        $password = $_POST['password'];

            $username = $mysqli->real_escape_string($username);
            $password = $mysqli->real_escape_string($password);

            
            $select = $mysqli->query("SELECT * FROM admin_accs WHERE username = '$username' and password = '$password'");
            $row = mysqli_fetch_array($select);
            
            if ($row['username'] == $username && $row['password'] == $password) {
                $id = $row['id'];
                $ai = base64_encode($id);  
                $update = $mysqli->query("UPDATE admin_accs SET status='1' WHERE id='$id'");
             
                header("Location: dashboard.php?ai=$ai");
                exit();
            }elseif($row['username'] != $username || $row['password'] != $password){
                $_SESSION['error'] = 'Incorrect username or password';
                header("Location: admin_login.php");
                exit();
            }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/admin_login.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Admin</title>
</head>
<body>
   <!-- <img src="../img/admin_loginBG.jpg" alt="Background" id="bg"> -->
    <div class="flexbox">
        
        <div class="form">

            <div class="form_control">
                <div class="form_title">
                    <h4>Admin</h4>
                </div>
                <form action="admin_login.php" method="POST">
                    <div class="inputs">

                        <div class="email_wrapper">
                            <span>Username</span>
                        
                            <input type="text" placeholder="Username" name="username">
                        </div>

                        <div class="password_wrapper">
                            <span>Password</span>
                            
                            <input type="password" placeholder="Password" id="password" name="password">
                            <i class="fas fa-eye fa-lg fa-fw" id="eye" onclick="toggle()"></i>
                        </div>

                        <div class="error_msg">
                            <?php
                                if(isset($_SESSION['error'])){
                                    echo $_SESSION['error'];
                                    unset($_SESSION['error']);
                                }
                            ?>
                        </div>

                        <div class="form_btn">
                            <button type="submit" id="submit" name="login">Login</button>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
    <script>
        var state = false;
        function toggle(){
            if(state){
                document.getElementById('password').setAttribute("type", "password");
                state = false;
            }else{
                document.getElementById('password').setAttribute("type", "text");
                state = true;
            }
        }
    </script>
</body>
</html>