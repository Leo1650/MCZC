<?php
include("../fu/db_conn.php");

$select_admin = $mysqli->query("SELECT * FROM admin_accs");
if(mysqli_num_rows($select_admin) != 0){
    $row_admin = mysqli_fetch_array($select_admin);

    if($row_admin['status'] == 0){
        header("Location: admin_login.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="bg"></div>
    <div class="sidebar">
        <div class="logo"><img src="../img/MCLogo.png" alt="Logo"></div>
        <ul>
            <li><a href="dashboard.php?ai=" id="dashboard">
                <span class="icon"><i class="fas fa-chart-line fa-lg fa-fw"></i></span>
                <span class="sidebar_title">Dashboard</span>
            </a></li>

            <li><a href="orders.php?st=NA==&&on=" id="orders">
                <span class="icon" ><i class="fas fa-tags"></i></span>
                <span class="sidebar_title">Orders</span>
            </a></li>

            <li><a href="products&category.php?pid=&&cid=" id="products">
                <span class="icon"><i class="fas fa-tshirt"></i></span>
                <span class="sidebar_title">Products</span>
            </a></li>

            

            <?php
                $default_cat = $mysqli->query("SELECT * FROM categories");
                if(mysqli_num_rows($default_cat) != 0){
                    $row_default_cat = mysqli_fetch_array($default_cat);
                    $enc_cat = base64_encode($row_default_cat['id']);
                }else{
                    $enc_cat = '';
                }
            ?>
            <li><a href="inventory.php?cat=<?php echo $enc_cat; ?>&&pid=" id="inventory">
                <span class="icon"><i class="fas fa-boxes fa-lg fa-fw"></i></span>
                <span class="sidebar_title">Inventory</span>
            </a></li>

    

            <li><a href="logout.php">
                <span class="icon"><i class="fas fa-sign-out-alt fa-lg fa-fw"></i></span>
                <span class="sidebar_title">Logout</span>
            </a></li>

            </ul>
    </div>

    <div class="toggle" onclick="toggleMenu()"></div>

    </div>

    <script>
         function toggleMenu(){
            let sidebar = document.querySelector('.sidebar');
            let toggle = document.querySelector('.toggle');
            let title = document.querySelector('.title');
            
            sidebar.classList.toggle('active');
            toggle.classList.toggle('active');
            title.classList.toggle('active');

        }
    </script>
    </body>
</html>