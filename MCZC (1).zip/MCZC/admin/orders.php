<?php
include("../fu/db_conn.php");
include("sidebar.php");
session_start();

$on =mysqli_real_escape_string($mysqli, $_GET['on']);
$st =mysqli_real_escape_string($mysqli, $_GET['st']);
$status = base64_decode($st);
$query = 'WHERE status = '.$status.'';
if($status == 4){
 $category = 'All Orders';
 $query = '';
}elseif($status == 0){
    $category = 'Pending';
    $query = 'WHERE status = '.$status.'';
}elseif($status == 1){
    $category = 'Processing';
}elseif($status == 2){
    $category = 'Out for Delivery';
}elseif($status == 3){
    $category = 'Order Received';
}

if(isset($_POST['update_status'])){
    $status_order = $_POST['status'];

    $update_order_status = $mysqli->query("UPDATE orders SET status = '$status_order' WHERE order_no = '$on' LIMIT 1");

    if($update_order_status){
        echo '<script>window.location = "orders.php?st='.$st.'&&on=";</script>';
        $_SESSION['message'] = "<div class='success_message'>Status Updated</div>";
        exit();
    }
}

//Update Status
if($on != ''){
    $update_order = $mysqli->query("SELECT * FROM orders WHERE order_no = '$on'");
    if(mysqli_num_rows($update_order) != 0){
        $row_update_order = mysqli_fetch_array($update_order);

        if($row_update_order['mode_of_payment'] == 'Paypal'){
            if($row_update_order['delivery_permission'] == 1){
                $payment_status = 'Paid';
            }else{
                 $payment_status = 'Pending';
            }
        }
        
    }


    echo ' <div class="form-overlay" id="update_status">
    <div class="form-wrapper">
        <div class="formbox">
            <div class="banner">
                <span id="form_title">Order Details</span>
                <a href="orders.php?st='.$st.'&&on=" class="cancel"><i class="fas fa-times fa-lg fa-fw"></i></a>
            </div> 
           
            <form action="orders.php?st='.$st.'&&on='.$on.'" method="POST" enctype="multipart/form-data">
                <div class="form-control">
                    
                    <div class="first_col">
                        <span class="label">Order I.D.: '.$on.'</span><br>
                        <span class="label">Date&Time: '.$row_update_order['date_ordered'].'</span><br>
                        <span class="label">Payment: '.$row_update_order['mode_of_payment'].'</span><br>';

                        if($row_update_order['mode_of_payment'] == 'Paypal'){
                            echo '<span class="label">Status: '.$payment_status.'</span><br>';
                        }

                        echo '<br>
                        <span class="label">Items:</span><br><br>
                            <div id="items_container">
                                    <ul class="label">';
                                $total_items = 0;
                                $order_details = $mysqli->query("SELECT * FROM order_details WHERE order_no = '$on'");
                                if(mysqli_num_rows($order_details) != 0){
                                    while($orders = mysqli_fetch_array($order_details)){
                                        echo '
                                        <li class="details">
                                            <div class="items">
                                                <img src="products_img/'.$orders["product_image"].'" alt="">
                                                <div class="item_control">
                                                    <span class="item_label">'.$orders["product_name"].'</span>
                                                    <span class="item_label">x'.$orders["quantity"].'</span>
                                                    <span class="item_label">'.$orders["size"].'</span>
                                                </div>
                                            </div>
                                        </li><br>
                                        ';

                                        $total_items += $orders["quantity"];

                                    }
                                }
         
                                    echo '</ul>
                            </div><br>
                                <span class="label">Total Items: x'.$total_items.'</span><br>
                                <span class="label">Amount: '.$row_update_order['amount'].'</span>
                        </div><br>

                    <div class="first_col">
                        <span class="label">Status</span>
                        <select name="status" id="status" class="input">';

                            if($row_update_order['status'] == 0){
                                echo '<option value="0">Pending</option>
                                <option value="1">Processing</option>
                                <option value="2">Out for Delivery</option>';
                            }elseif($row_update_order['status'] == 1){
                                echo '<option value="1">Processing</option>
                                <option value="0">Pending</option>
                                <option value="2">Out for Delivery</option>';
                            }elseif($row_update_order['status'] == 2){
                                echo '<option value="2">Out for Delivery</option>
                                <option value="0">Pending</option>
                                <option value="1">Processing</option>';
                            }elseif($row_update_order['status'] == 3){
                                echo '<option value="3">Received</option>';
                            }
                        echo '</select>
                    </div>

                    <div class="second_col">
                        <div class="action-btn">
                            <input type="submit" value="Save" id="create" name="update_status">
                        </div>
                    </div>
                   
                </div>
            </form>
        </div>
    </div>
</div>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/orders.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title> Orders</title>
</head>
-
+
<body>
    <div class="title">
        <h1><?php echo $category; ?></h1>
        <select name="category" id="select_cat">
                                    <?php
                                        if($status == 4){
                                            echo '<option value="4">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Received</option>';
                                        }elseif($status == 0){
                                            echo '<option value="0">Pending</option>
                                            <option value="4">All Orders</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Received</option>';
                                        }elseif($status == 1){
                                            echo '<option value="1">Processing</option>
                                            <option value="4">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Received</option>';
                                        }elseif($status == 2){
                                            echo '<option value="2">Out for Delivery</option>
                                            <option value="4">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="3">Received</option>';
                                        }elseif($status == 3){
                                            echo '<option value="3">Order Received</option>
                                            <option value="4">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>';
                                        }

                                    ?>
                                </select>
        
    </div>
    
    <div class="content_body">
        <div class="products_section" id="inventory_section">
                <div class="product_table" id="inventory_table">
                        <table class="tables" id="orders_download">
                            <thead>
                                <tr>
                                    <th class="product_name">Order I.D.</th>
                                    <th class="product_large">Date&Time</th>
                                    <th class="product_regular">Customer Name</th>
                                    <th class="product_medium">Address</th>
                                    <th class="product_overdose">Amount</th>
                                    <th class="product_category">Status</th>
                                    <th class="product_category">View</th>
                            
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $select_all_orders = $mysqli->query("SELECT * FROM orders $query");
                                    
                                    if(mysqli_num_rows($select_all_orders) != 0){
                                    
                                        while($row_orders = mysqli_fetch_array($select_all_orders)){
                                            $user_id = $row_orders['user_id'];
                                            $select_user = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
                                            if(mysqli_num_rows($select_user) != 0){
                                                $selected_user = mysqli_fetch_array($select_user);
                                            }
                                            echo '<tr>
                                            <td class="product_name">'.$row_orders['order_no'].'</td>

                                            <td class="product_large">
                                                <span>'.$row_orders['date_ordered'].'</span>
                                            </td>
            
                                            <td class="product_regular">
                                                <span>'.$selected_user['firstname'].'  '.$selected_user['lastname'].'</span>
                                            </td>

                                            
            
                                            <td class="product_medium">
                                                <span>'.$row_orders['address'].'</span>
                                            </td>
            
                                            
            
                                            <td class="product_overdose">
                                                <span>'.$row_orders['amount'].'</span>
                                            </td>';
                                            
                                                if($row_orders['status'] == 0){
                                                    $stat = 'Pending';
                                                }elseif($row_orders['status'] == 1){
                                                    $stat = 'Processing';
                                                }elseif($row_orders['status'] == 2){
                                                    $stat = 'On Delivery';
                                                }elseif($row_orders['status'] == 3){
                                                    $stat = 'Received';
                                                }
                                        
                                            echo '<td class="product_category">
                                                <span>'.$stat.'</span>
                                            </td>

                                            <td class="product_category">
                                                <a href="orders.php?st='.$st.'&&on='.$row_orders['order_no'].'"><i class="fas fa-eye fa-lg fa-fw"></i></a>
                                            </td>
            
                                            </tr>';
                                            
                                            
                                        }
                                    }else{
                                        echo '<tr>
                                            <td colspan=7 style="text-align: center; color: red;">No Orders</td>
                                            </tr>';
                                    }


                                ?>
                                                    
                            </tbody>
                        </table>
                    </div>

               
            </div>

        
    </div> 
    

    <?php
        if(isset($_SESSION['message'])){
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
    ?>


    <script src="../js/orders.js"></script>

    <script type="text/javascript" src="../src/jquery-3.3.1.slim.min.js"></script>

    <script type="text/javascript" src="../src/jspdf.min.js"></script>

    <script type="text/javascript" src="../src/jspdf.plugin.autotable.min.js"></script>

    <script type="text/javascript" src="../src/tableHTMLExport.js"></script>

    <script type="text/javascript">

    $("#download").on("click",function(){
        $("#orders_download").tableHTMLExport({
        type:'csv',
        filename:'Orders.csv'
        });
    });
    </script>
</body>
</html>