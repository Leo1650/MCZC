<?php
include("../fu/db_conn.php");
session_start();
if(isset($_POST['submit'])){
  $OTP = $_POST['OTP'];

  $select_admin = $mysqli->query("SELECT * FROM admin_accs");
  $row = mysqli_fetch_array($select_admin);
  $ai = base64_encode($row['id']);

  if($row['OTP'] == $OTP){
    header("Location: dashboard.php?ai=$ai");
  }else{
    $_SESSION['error'] = '<p style="color: red; font-size: 10pt; text-align: center;">OTP do not match</p>';
    header("Location: admin_validate.php");
    exit();
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin</title>
  <link rel="stylesheet" href="../css/admin_validate.css">
  <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">


</head>

<body>
  <div class="container">

  <div class="form">
  <form action="admin_validate.php" method="POST" >
      <p style="text-align: center;font-size: 20px;"><b>Admin Verification</b> </p>
      <p style="padding: 20px;"><label>A verification code has been sent to your email address, please enter it below.</label><br>
      <input class="form1"  name="OTP" type="text">
      <?php
        if(isset($_SESSION['error'])){
            echo $_SESSION['error'];
            unset($_SESSION['error']);
        }
      ?>
      
      <button class="button" type="submit" name="submit">Submit</button></p>
      
    </form>
    <br>
  <br>
  </div>
   
</div>


</body>
</html>