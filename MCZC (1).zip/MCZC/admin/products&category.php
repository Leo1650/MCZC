<?php
session_start();
include("sidebar.php");
include("../fu/db_conn.php");

$pid =mysqli_real_escape_string($mysqli, $_GET['pid']);
$cid =mysqli_real_escape_string($mysqli, $_GET['cid']);


if(isset($_POST['add_product'])){
    $name = $_POST['name'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $regular_stock = $_POST['regular_stock'];
    $large_stock = $_POST['large_stock'];
    $regular_price = $_POST['regular_price'];
    $large_price = $_POST['large_price'];

    $image =  $_FILES['image']['name'];
    $image_type = $_FILES['image']['type'];
    $image_size = $_FILES['image']['size'];
    $image_loc = $_FILES['image']['tmp_name'];
    $image_store = "products_img/".$image;
    

    $insert_product = $mysqli->query("INSERT INTO products (name, description, category, regular_stock, large_stock, regular_price, large_price, image) VALUES ('$name', '$description', '$category', '$regular_stock', '$large_stock', '$regular_price', '$large_price', '$image')");

    move_uploaded_file($image_loc, $image_store);

    if($insert_product){
        header("Location: products&category.php?pid=&&cid=");
        $_SESSION['message'] = "<div class='success_message'>New Product Added</div>";
        exit();
    }else{
        echo "error";
    }
}elseif(isset($_POST['add_category'])){
    $name = $_POST['name'];

    $insert_category = $mysqli->query("INSERT INTO categories (name) VALUES ('$name')");
    
    if($insert_category){
        header("Location: products&category.php?pid=&&cid=");
        $_SESSION['message'] = "<div class='success_message'>New Category Added</div>";
        exit();
    }
}elseif(isset($_POST['add_category2'])){
    $name = $_POST['name'];

    $insert_category = $mysqli->query("INSERT INTO categories (name) VALUES ('$name')");
    
    if($insert_category){
        header("Location: products&category.php?pid=&&cid=");
        $_SESSION['message'] = "<div class='success_message'>New Category Added</div>";
        $_SESSION['cat'] = 'set';
        exit();
    }
}

if($pid != ''){
    $p_id = base64_decode($pid);
    $all_products = $mysqli->query("SELECT * FROM products WHERE id = '$p_id'");
    if(mysqli_num_rows($all_products) != 0){                   
        $row_product_edit = mysqli_fetch_array($all_products);
    }

    
            
    //Edit Product
    echo '<div class="form-overlay" id="edit_product">
    <div class="form-wrapper">
        <div class="formbox">
            <div class="banner">
            <span id="form_title">Edit Product</span>
                <div class="cancel" onclick="cancel_edit_product()"><i class="fas fa-times fa-lg fa-fw"></i></div>
            </div>

           
            <form action="../fu/edit.php?pid='.$pid.'" method="POST" enctype="multipart/form-data">
                <div class="form-control">
                    
                    <div class="first_col">
                        <span>Name:</span>
                        <input type="text" placeholder="Name" class="input" required name="name" value="'.$row_product_edit["name"].'">

                        <span>Description:</span>
                        <textarea name="description" cols="5" rows="5" class="des">'.$row_product_edit["description"].'</textarea>

                        
                    <span>Picture:</span>
                        <div class="picture">
                            <input type="file" name="image" id="edit-pic" >
                            <img src="products_img/'.$row_product_edit["image"].'" id="img-change">
                        </div>
                        <div id="picture-edit" onclick="EditPhoto()">Choose a photo</div>

                    </div>

                    <div class="second_col">

                        <div class="stock_prize">
                            <div class="stock">

                            <span>Category:</span>
                        <select name="category" class="input">';

                    $cat_id = $row_product_edit['category'];
                    $select_category = $mysqli->query("SELECT * FROM categories WHERE id = '$cat_id' ");
                        if(mysqli_num_rows($select_category) != 0){
                            $row_cat = mysqli_fetch_array($select_category);
                        }
                            echo '<option value="'.$row_cat['id'].'">'.$row_cat['name'].'</option>';

                    $all_category = $mysqli->query("SELECT * FROM categories");
                    if(mysqli_num_rows($all_category) != 0){
                        while($row_all_cat = mysqli_fetch_array($all_category)){

                            if($cat_id != $row_all_cat['id']){
                                echo '<option value="'.$row_all_cat['id'].'">'.$row_all_cat['name'].'</option>';
                            }else{
                                //don't display
                            }
                           

                        }
                    }else{
                        echo '<option value="">Please Create Category</option>';
                    }

                      
                    echo  '</select>


                            <span>Available Stocks:</span>
                                <span class="stock_label">Regular:</span>
                                <input type="number" name="regular_stock" class="stocks" placeholder="Regular" value="'.$row_product_edit["regular_stock"].'">
                                <span class="stock_label">Large:</span>
                                <input type="number" name="large_stock" class="stocks" placeholder="Large" value="'.$row_product_edit["large_stock"].'">
                                
                            
                                
                                </div>

                            <div class="prizes">
                                <span>Price:</span><br>
                                    <input type="number" name="regular_price" class="stocks" placeholder="0.00" value="'.$row_product_edit["regular_price"].'">
                                    <input type="number" name="large_price" class="stocks" placeholder="0.00" value="'.$row_product_edit["large_price"].'">
                                    
                            </div>
                        </div>

                        

                        <div class="action-btn">
                            <input type="submit" value="Save" id="create" name="editProduct">

                        </div>
                    </div>  

                </div>
            </form>
        </div>
    </div>
</div>';
}elseif($cid != ''){
    $c_id = base64_decode($cid);
    $all_categories = $mysqli->query("SELECT * FROM categories WHERE id = '$c_id'");
    if(mysqli_num_rows($all_categories) != 0){                   
        $row_category_edit = mysqli_fetch_array($all_categories);
    }

    echo ' <div class="form-overlay" id="edit_category">
    <div class="form-wrapper">
        <div class="formbox2">
            <div class="banner">
            <span id="form_title">Edit Category</span>
                <div class="cancel" onclick="cancel_edit_product()"><i class="fas fa-times fa-lg fa-fw"></i></div>
            </div>
            
            <form action="../fu/edit.php?pid=&&cid='.$cid.'" method="POST" enctype="multipart/form-data">
                <div class="form-control">
                    
                    <div class="first_col">
                        <span>Name:</span>
                        <input type="text" placeholder="Name" class="input" required name="name" value="'.$row_category_edit['name'].'">
                    </div>

                    <div class="second_col">
                        <div class="action-btn">
                            <input type="submit" value="Save" id="create" name="edit_category">
                        </div>
                    </div>
                   
                </div>
            </form>
        </div>
    </div>
</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/products&category.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title>Products</title>
</head>
<body>
    <div class="title">
        <h1>Products</h1>
    </div>
    
    <div class="content_body">
    <div class="product_title">Products</div>
    <button id="add" onclick="add_product()"><i class="fas fa-plus fa-lg fa-fw"></i> Add Product</button>
        <div class="products_section">
            <div class="product_wrapper">
                

                <div class="product_table">
                    <table class="tables">
                        <thead>
                            <tr>
                            <th class="product_photo">Photo</th>
                                <th class="product_name">Name</th>
                                <th class="product_category">Category</th>
                                
                                <th class="product_regular">Regular</th>
                                <th class="product_regular">Large</th>
                               
                                <th class="product_action">Edit</th>
                                <th class="product_action">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $select_all_products = $mysqli->query("SELECT * FROM products");
                                if(mysqli_num_rows($select_all_products) != 0){
                                
                                    while($row_product = mysqli_fetch_array($select_all_products)){
                                        $cat_id = $row_product['category'];
                                        $enc_id = base64_encode($row_product['id']);

                                        $select_category = $mysqli->query("SELECT * FROM categories WHERE id = '$cat_id' ");
                                        if(mysqli_num_rows($select_category) != 0){
                                            $row_cat = mysqli_fetch_array($select_category);
                                        }
                                        
                                        echo '<tr>
                                        <td class="product_pic">
                                        <span><img src="products_img/'.$row_product['image'].'" alt=""></span>
                                        </td>

                                        <td class="product_name">'.$row_product['name'].'</td>

                                       

                                        <td class="product_category">
                                        <span>'.$row_cat['name'].'</span>
                                        </td>
        
                                        
        
                                        <td class="product_regular">
                                            <span><span>&#8369</span> '.$row_product['regular_price'].'</span>
                                        </td>

                                        <td class="product_regular">
                                        <span><span>&#8369</span> '.$row_product['large_price'].'</span>
                                        </td>
        
        
                                        <td class="product_edit_btn">
                                            <a href="products&category.php?pid='.$enc_id.'&&cid="><i class="fas fa-edit fa-lg fa-fw"></i></a
                                        </td>

                                        <td class="product_delete_btn">
                                            <a href="../fu/delete_product.php?pid='.$row_product['id'].'"><i class="fas fa-trash fa-lg fa-fw"></i></a>
                                        </td>
        
                                        </tr>';
                                    }
                                }else{
                                    echo '<tr>
                                    <td class="product_name" colspan=8 style="text-align: center; color: red;">No products</td>
                                    </tr> ';
                                }
                            ?>
                                                     
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    <div class="product_title">Category</div>
    <button id="add" onclick="add_category()"><i class="fas fa-plus fa-lg fa-fw"></i> Add Category</button>
        <div class="products_section" id="category">
            <div class="product_wrapper" id="catWrapper">

                <div class="category_table">
                    <table class="tables">
                        <thead>
                            <tr>
                                <th class="product_name">Name</th>
                                <th class="product_action">Edit</th>
                                <th class="product_action">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $select_all_category = $mysqli->query("SELECT * FROM categories");
                                if(mysqli_num_rows($select_all_category) != 0){
                                
                                    while($row_category = mysqli_fetch_array($select_all_category)){
                                        $enc_cid = base64_encode($row_category['id']);
                                        echo '<tr>
                                        <td class="product_name">'.$row_category['name'].'</td>
        
                                        <td class="product_edit_btn">
                                            <a href="products&category.php?pid=&&cid='.$enc_cid.'"><i class="fas fa-edit fa-lg fa-fw"></i></a>
                                        </td>

                                        <td class="product_delete_btn">
                                        <a href="../fu/delete_category.php?cid='.$row_category['id'].'"><i class="fas fa-trash fa-lg fa-fw"></i></a>
                                    </td>
        
                                        </tr>';
                                    }
                                }else{
                                    echo '<tr>
                                            <td colspan=2 style="text-align: center; color: red;">No Category</td>
                                        </tr>';
                                }
                            ?>

                          
                                                      
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div> 

    <?php
    if(isset($_SESSION['cat'])){
        $style = 'style = "display: block;"';
        unset($_SESSION['cat']);
    }else{
        $style = '';
    }
    ?>
         <!--Add new Products-->
         <div class="form-overlay" id="add_product" <?php echo $style; ?>> 
            <div class="form-wrapper">
                <div class="formbox">
                    <div class="banner">
                    <span id="form_title">Add New Product</span>
                        <div class="cancel" onclick="cancel_product()"><i class="fas fa-times fa-lg fa-fw"></i></div>
                    </div>
                    
                    <form action="products&category.php" method="POST" enctype="multipart/form-data">                      
                        <div class="form-control">                           
                            <div class="first_col">
                                <span>Name:</span>
                                <input type="text" placeholder="Name" class="input" required name="name">

                                <span>Description:</span>
                                <textarea name="description" cols="5" rows="5" class="des" placeholder="optional"></textarea>
                                
                                <span>Picture:</span>
                                <div class="picture">
                                    <input type="file" name="image" id="pic" >
                                    <img src="" id="img">
                                </div>
                                <div id="pictureBtn" onclick="ChoosePhoto()">Choose a photo</div>
                            </div>

                            <div class="second_col">
                                <div class="stock_prize">
                                    <div class="stock">

                                    <span>Select Category:</span>
                                <select name="category" class="input" required>
                                    <?php
                                        $all_category = $mysqli->query("SELECT * FROM categories");
                                        if(mysqli_num_rows($all_category) != 0){
                                            while($row_all_cat = mysqli_fetch_array($all_category)){

                                                echo '<option value="'.$row_all_cat['id'].'">'.$row_all_cat['name'].'</option>';

                                            }
                                        }else{
                                            echo '<option value="">Please Create Category</option>';
                                        }

                                    ?>
                                    
                                </select>     

                                    <span>Add Stocks:</span>
                                        <span class="stock_label">Regular:</span>
                                        <input type="number" name="regular_stock" class="stocks" placeholder="Regular" required>
                                        <span class="stock_label">Large:</span>
                                        <input type="number" name="large_stock" class="stocks" placeholder="Large" required>                                
                                    </div>

                                    <div class="prizes">
                                    <div class="stock">
                                        <span>Price:</span>
                                            <input type="number" name="regular_price" class="stocks" placeholder="Price" required>
                                            <input type="number" name="large_price" class="stocks" placeholder="Price" required>
                        
                                    </div>     
                                    </div>


                                </div>
                                <div class="action-btn">
                                    <input type="submit" value="Save" id="create" name="add_product">

                            </div>  
                                </div>   
                                
                        </div>

                            
                        
    
                    </form>
                </div>
            </div>
            
        <?php 
            if(isset($_SESSION['message'])){
                echo $_SESSION['message'];
               // unset($_SESSION['message']);
            }elseif(isset($_SESSION['message_err'])){
                echo $_SESSION['message_err'];
              //  unset($_SESSION['message_err']);
            }
        ?>

        </div>

         <!--Add new Category-->
         <div class="form-overlay" id="add_category">
            <div class="form-wrapper">
                <div class="formbox2">
                    <div class="banner">
                    <span id="form_title">Add Category</span>
                        <div class="cancel" onclick="cancel_product()"><i class="fas fa-times fa-lg fa-fw"></i></div>
                    </div>
                    
                    <form action="products&category.php?pid=" method="POST" enctype="multipart/form-data">
                        <div class="form-control">
                            
                            <div class="first_col">
                                <span>Name:</span>
                                <input type="text" placeholder="Name" class="input" required name="name">
                            </div>

                            <div class="second_col">
                                <div class="action-btn">
                                    <input type="submit" value="Save" id="create" name="add_category">
                                </div>
                            </div>
                           
                        </div>
                    </form>
                </div>
            </div>
        </div>

         <!--Add new Category 2-->
         <div class="form-overlay" id="add_category2">
            <div class="form-wrapper">
                <div class="formbox2">
                    <div class="banner">
                    <span id="form_title">Add Category</span>
                    <div class="cancel" onclick="cancel_product()"><i class="fas fa-times fa-lg fa-fw"></i></div>
                    </div>
                    
                    <form action="products&category.php?pid=" method="POST" enctype="multipart/form-data">
                        <div class="form-control">
                            
                            <div class="first_col">
                                <span>Name:</span>
                                <input type="text" placeholder="Name" class="input" required name="name">
                            </div>

                            <div class="second_col">
                                <div class="action-btn">
                                    <input type="submit" value="Save" id="create" name="add_category2">
                                </div>
                            </div>
                           
                        </div>
                    </form>
                </div>
            </div>
        </div>
       

        <?php 
            if(isset($_SESSION['message'])){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }elseif(isset($_SESSION['message_err'])){
                echo $_SESSION['message_err'];
                unset($_SESSION['message_err']);
            }
        ?>

    
    <script>

            let product = document.getElementById("add_product");
            let category = document.getElementById("add_category");
            let category2 = document.getElementById("add_category2");

            function add_product(){
                product.style.display = "block";
                
            }
            function cancel_product(){
                product.style.display = "none";
                category.style.display = "none";
                category2.style.display = "none";
            }
            function add_category(){
                category.style.display = "block";
            }
            function add_category2(){
                category2.style.display = "block";
            }

            function cancel_edit_product(){
                var param = new URLSearchParams(window.location.search);
                var pid = param.get('pid');
                window.location.href = "products&category.php?pid=&&cid=";
            }
            document.getElementById("add_cat").addEventListener("click", function(event){
                event.preventDefault()
            });


    </script>

    <script src="../js/products&category.js"></script>
</body>
</html>