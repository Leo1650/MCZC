<?php
include("fu/db_conn.php");
session_start();

if(!isset($_SESSION["guessID"])){
    $user_id = generateKey($mysqli);
    $_SESSION['guessID'] = $user_id;
}
$user_id = $_SESSION['guessID'];
$id = base64_encode($user_id);

$select_num_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
if(mysqli_num_rows($select_num_cart) != 0){
    $total_items = mysqli_num_rows($select_num_cart);
}else{
    $total_items = 0;
}


//Generate Guess ID.
function checkKeys($mysqli, $randStr){

    $result = $mysqli->query("SELECT * FROM cart");
    if(mysqli_num_rows($result) != 0){
        while($row = mysqli_fetch_array($result)){
            if($row['user_id'] == $randStr){
                $keyExist = true;
                break;
            }else{
                $keyExist = false;
            }
        }
    }else{
        $keyExist = false;    
    }
    return $keyExist;
}

function generateKey($mysqli){
    $keylength = 5;
    $str = "1234567890";
    $randStr = substr(str_shuffle($str), 0, $keylength);


    $checkKey = checkKeys($mysqli, $randStr);

    while($checkKey == true){
        $randStr = substr(str_shuffle($str), 0, $keylength);
        $checkKey = checkKeys($mysqli, $randStr);
    }

    return $randStr;
}
//End Order no.

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="shortcut icon" type="image/png" href="img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Homepage</title>
</head>
<body>

<div class="navbar">
        <div class="hamburger" id="hamburger" onclick="show_nav()"><i class="fas fa-bars"></i></div>
        <div class="exit" id="exit" onclick="hide_nav()"><i class="fas fa-times"></i></div>
        <div class="navbar_wrapper">

            <div class="logo">
                <img src="img//MCLogo.png" alt="Logo">
            </div>

            <div class="link_wrapper" id="links">
                <ul>
                    <li><a href="" id="home"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="user/product_list.php?ui=<?php echo $id; ?>&&cid=MA==" id="product"><i class="fas fa-tshirt"></i> Shop</a></li>
                    <li><a href="user/cart.php?ui=<?php echo $id; ?>" id="cart"><i class="fas fa-shopping-cart"></i> Cart<span id="counter"><p><?php echo $total_items; ?></p></span></a></li>
                    <li><a href="user/login.php"><i class="fas fa-sign-in-alt"></i> Sign in</a></li>
                    
                </ul>
            </div>
        </div>
</div>


    <div class="banner_wrapper">
    <img src="img/Banner_MC.jpg" alt="Logo">

            
        
    </div>

    <div class="best_seller_section">
        <div class="best_seller_title"><p>Featured Products</p></div>
        <div class="best_seller_body">
            <div class="all_product_wrapper">

            <?php
                $select_featured_product = $mysqli->query("SELECT * FROM products ORDER BY rand() LIMIT 8");
                if(mysqli_num_rows($select_featured_product) != 0){
                    $default_size = base64_encode('Regular');
                    while($row_featured = mysqli_fetch_array($select_featured_product)){
                        $item_id = base64_encode($row_featured['id']);
                        echo '<div class="product_wrapper">
                            <div class="product_control">
                                <div class="product_img"><a href="user/item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'"><img src="admin/products_img/'.$row_featured['image'].'" alt="Product Picture"></a></div>
                                <div class="details">
                                <div class="product_name">'.$row_featured['name'].'</div>
                                <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].'</div>
                                <input type="hidden" name="prodID" value="'.$row_featured['id'].'">
                                <input type="hidden" name="userID" value="'.$user_id.'">
                                <div class="product_btn"><a href="user/item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'">Buy Now</a></div>
                                </div>
                            </div>
                        </div>';
                    }
                }
            ?>           
                
            </div>
        </div> 
    </div>

    <div class="cart_feedback" id="feedbackBox">
        <i id="iconMsg"></i>
        <p id="feedbackMsg"></p>
    </div>



    <script>
        let hamburger = document.getElementById('hamburger');
        let exit = document.getElementById('exit');
        let links = document.getElementById('links');

        function show_nav(){
            hamburger.style.display = "none";
            exit.style.display = "block";
            links.style.left = '0';
        }
        function hide_nav(){
            hamburger.style.display = "block";
            exit.style.display = "none";
            links.style.left = '-100%';
        }
        var options = document.getElementById('options');
        function show_options(){
            options.style.display = "block";
        }
        function hide_options(){
            options.style.display = "none";
        }
        var profile = document.getElementById('drop_profile');
        function show_profile(){
            profile.style.display = "block";
        }
        function hide_profile(){
            profile.style.display = "none";
        }

      
    </script>

    <script type="text/javascript">

            $(document).on('click','.AddToCart',function () {
                var prodId  = $(this).closest('.product_wrapper').find('input[name=prodID]').val();
                var userId  = $(this).closest('.product_wrapper').find('input[name=userID]').val();

                console.log(prodId);
                console.log(userId);

                var feedbackBox = document.getElementById("feedbackBox");
                var feedbackMsg = document.getElementById("feedbackMsg");
                feedbackMsg.innerHTML = "Product Added to Cart";

                var icon = document.getElementById("iconMsg");


                $.ajax({
                    type: "POST",
                    url: "fu/addToCart.php",
                    data: {
                        prodID : prodId,
                        userID : userId,
                    },
                    dataType: "json",
                    encode: true,
                    }).done(function (data) {
                        console.log(data);
                        $("#links").load(location.href + " #links > *");
                        if(data['Feedback'] != ''){
                            feedbackMsg.innerHTML = data['Feedback'];
                        }

                        if(data['flag'] == 0){
                            icon.className = "fas fa-times-circle"
                            icon.style.color = "red";
                        }else{
                            icon.className = "fas fa-check"
                            icon.style.color = "#2bd573";
                        }

                        feedbackBox.style.display = "block";
                });

                feedbackBox.addEventListener("animationend", (ev) => {
                if (ev.type === "animationend") {
                    feedbackBox.style.display = "none";
                }
                }, false);

            });

    </script>
</body>
</html>

<?php
include("user/footer.php");
?>
