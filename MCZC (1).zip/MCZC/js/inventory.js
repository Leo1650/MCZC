var param = new URLSearchParams(window.location.search);
var cat = param.get('cat');

var selected = document.getElementById("select_cat");        
    select_cat.addEventListener("change", function(){
        cat = btoa(selected.value)
        window.location.href = "../admin/inventory.php?cat="+cat+"";
        
});