<?php

include("db_conn.php");

$data = [];

$data['success'] = true;
$data['message'] = 'Success!';

if(isset($_POST['prodID'])){
    $userID = $_POST['userID'];
    $product_id = $_POST['prodID'];
    $quantity = 1;
    $size = "Regular";

    $check_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
    if(mysqli_num_rows($check_product) != 0){
        $row_product = mysqli_fetch_array($check_product);

        $category_id = $row_product['category'];
        $product_image = $row_product['image'];
        $product_name = $row_product['name'];
        $price = $row_product['regular_price'];

        if($size == 'Regular'){

            $data['Product'] = $category_id . ", " . $product_name . ", " . $product_image . ", " . $price;

            if($row_product['regular_stock'] == 0){
            // header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
            //     $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='far fa-exclamation-triangle' style='color: red;'></i><br>".$size." ".$row_product['name']." is Out of Stock</div>";
                $data['Feedback'] = $row_product['name'] . " Regular is out of stock";
                $data['flag'] = 0;

            }elseif($quantity > $row_product['regular_stock']){
                // header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                // $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='far fa-exclamation-triangle' style='color: red;'></i><br>Sorry! We only have ".$row_product['regular_stock']." ".$size." ".$row_product['name']."</div>";
                $data['Feedback'] = "We only have" . $row_product['regular_stock'] . "of " . $row_product['name'];
                $data['flag'] = 0;

            }else{
                $data['Product'] = $category_id . ", " . $product_name . ", " . $product_image . ", " . $price;
                $check_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$userID' AND product_id = '$product_id' AND size = '$size' ");
                if(mysqli_num_rows($check_cart) != 0){
                    $row_cart_check = mysqli_fetch_array($check_cart);
                    $quantity += $row_cart_check['quantity'];
                    $update_product_qty = $mysqli->query("UPDATE cart SET quantity = '$quantity' WHERE product_id = '$product_id' AND size = '$size' AND user_id = '$userID'");
            
                    if($update_product_qty){
                        // header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                        // $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check'></i><br> Product has been added to your cart</div>";
                        // exit();
                        $data['Feedback'] = 'Product has been added to cart';
                        $data['flag'] = 1;
                    }
                }else{
                    $insert_to_cart = $mysqli->query("INSERT INTO cart (user_id, product_id, category_id, product_image, product_name, price, size, quantity) VALUES ('$userID', '$product_id', '$category_id', '$product_image', '$product_name', '$price', '$size', '$quantity')");
            
                    if($insert_to_cart){
                        // header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                        // $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check'></i><br> Product has been added to your cart</div>";
                        // exit();
                        $data['Feedback'] = 'Product has been added to cart';
                        $data['flag'] = 1;
                    }else{
                        $data['success'] = false;
                        $data['message'] = 'Failed!';
                    }
                }
            }
        }
    }


   
    $data['success'] = true;
    $data['message'] = 'Success!';
    echo json_encode($data);
}

?>
