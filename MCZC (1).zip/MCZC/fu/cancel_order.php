<?php
include("db_conn.php");
session_start();
    $on =mysqli_real_escape_string($mysqli, $_GET['on']);
    $ui =mysqli_real_escape_string($mysqli, $_GET['ui']);

    $user_id = base64_encode($ui);
    $delete_order = $mysqli->query("DELETE FROM orders WHERE user_id = '$ui' AND order_no = '$on' LIMIT 1");
if($delete_order){
    $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check-circle'></i><br>Order Canceled</div>";
    header('Location: ../user/trackOrder.php?ui='.$user_id.'');
}else{
    echo "Failed";
}


?>