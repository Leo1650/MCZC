<?php
    $host = "localhost";
    $dbUsername = "u524035408_mczc";
    $dbPassword = "@Mczcdb123";
    $dbName = "u524035408_meryendacraves";
    $mysqli = new mysqli($host, $dbUsername, $dbPassword, $dbName);
?>