
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/navbar.css">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <title>Footer</title>
</head>
<body>


<div class="footer">
        <div class="footer_control">
            <div class="footer_title"><p>Meryenda Craves Zamboanga City</p></div>
            <div class="footer_links">
                <a href="#">Follow us on: <i class="fab fa-facebook-square"></i></a><span> |</span>
                <a href="#">Terms & Condition</a><span> |</span>
                <a href="#">Privacy Policy</a><span></span>
            </div>
            <a href="#" style="text-decoration: none; color: white; font-size: 10pt;">Contact Us:</a><span> mcsupport@gmail.com</span>

        </div>
    </div>
</body>
</html>
