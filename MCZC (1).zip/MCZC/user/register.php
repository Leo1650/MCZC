<?php
include("../fu/db_conn.php");
include('../smtp/PHPMailerAutoload.php');
session_start();

if(isset($_POST['register'])){
    $email = $_POST['email'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    $_SESSION['firstname_input'] = $firstname;
    $_SESSION['lastname_input'] = $lastname;
    $_SESSION['email_input'] = $email;
    $_SESSION['password_input'] = $password;

    $select_email = $mysqli->query("SELECT * FROM users WHERE email = '$email'");

//Email Restrictions
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $_SESSION['email'] = '<p class="error">Invalid Email</p>';
    }else{
        if(mysqli_num_rows($select_email) != 0){
            $_SESSION['email'] = '<p class="error">Email already in use</p>';
        }
    }

//First name restrictions
    if(strlen($firstname) < 2){
        $_SESSION['firstname'] = '<p class="error">Firstname must be atleast 2 characters</p>';
    
    }else if(!ctype_alpha($firstname)){
        $_SESSION['firstname'] = '<p class="error">Please use alphabetical characters only</p>';
    }

//Lastname Restrictions
    if(strlen($lastname) < 2){
        $_SESSION['lastname'] = '<p class="error">Lastname must be atleast 2 characters</p>';

    }else if(!ctype_alpha($lastname)){
        $_SESSION['lastname'] = '<p class="error">Please use alphabetical characters only</p>';
    }

//Pasword Restrictions
    if(strlen($password) < 8) {
        $_SESSION['password'] = '<p class="error">password must be atleast 8 characters</p>';
    }else if(strlen($password) > 7){
        if($password != $password2){
            $_SESSION['password2'] = '<p class="error">password do not match</p>';
        }
    }


    if(strlen($firstname) > 1 && strlen($lastname) > 1 && strlen($password) > 7 && $password == $password2  && mysqli_num_rows($select_email) == 0){
        $firstname = $mysqli->real_escape_string($firstname);
        $lastname = $mysqli->real_escape_string($lastname);
        $email = $mysqli->real_escape_string($email);
        $password = $mysqli->real_escape_string($password);
        $password2 = $mysqli->real_escape_string($password2);

        $vkey = md5(time().$firstname);

        $password = md5($password);
        
        $insert = $mysqli->query("INSERT INTO users(firstname, lastname, email, password, verification_key) VALUES ('$firstname', '$lastname', '$email', '$password', '$vkey')");

        if($insert){
            $message = "<a href='http://meryendacraves.store/user/confirmAcc.php?vkey=$vkey'>Verify Account";
            smtp_mailer($email, 'Email Verification', $message); 
            unset($_SESSION['firstname_input']);
            unset($_SESSION['lastname_input']);
            unset($_SESSION['email_input']);
            unset($_SESSION['password_input']);
            echo '<script>alert("Registration Successful. Please verify your account.")</script>';
        }else{
            header("Location: register.php");
        }
    }
}

function smtp_mailer($to,$subject, $msg){
    $mail = new PHPMailer(true);
    //$mail->SMTPDebug = 1;
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Username = "ssmtp1560@gmail.com";
    $mail->Password = "smtpsupport123";
    $mail->SetFrom("ssmtp1560@gmail.com");
    $mail->Subject = $subject;
    $mail->Body = $msg;
    $mail->AddAddress($to);
    $mail->SMTPOptions=array('ssl'=>array(
        'verify_peer'=>false,
        'verify_peer_name'=>false,
        'allow_self_signed'=>false
    ));
    if(!$mail->Send()){
        return 0;
    }else{
        return 1;
    }
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Register</title>
</head>
<body>
    <div class="flexbox">
        <div class="form">
            

           <?php
                //Inputs
                if(isset($_SESSION['firstname_input'])){
                    $first_input = $_SESSION['firstname_input'];   
                }else{
                    $first_input = '';
                }

                if(isset($_SESSION['lastname_input'])){
                    $last_input = $_SESSION['lastname_input'];
                }else{
                    $last_input = '';
                }

                if(isset($_SESSION['email_input'])){
                    $email_input = $_SESSION['email_input'];
                }else{
                    $email_input = '';
                }

                if(isset($_SESSION['password_input'])){
                    $password_input = $_SESSION['password_input'];
                }else{
                    $password_input = '';
                }
           ?>

            <div class="form_control">
                <div class="form_title">
                    <h4>Create Account</h4>
                </div>
                <form action="register.php" method="POST">
                    <div class="inputs">
                        <div class="name">
                            <div class="name_wrapper" id="first">
                                <span>First Name</span>
                                <input type="text" name="firstname" value="<?php echo $first_input; ?>" required>
                                <?php
                                if(isset($_SESSION['firstname'])){
                                    echo $_SESSION['firstname'];
                                    unset($_SESSION['firstname']);
                                } 
                                unset($_SESSION['firstname_input']);
                                ?>
                            </div>

                            <div class="name_wrapper">
                                <span>Last Name</span>
                                <input type="text" name="lastname" value="<?php echo $last_input; ?>" required>
                                <?php
                                if(isset($_SESSION['lastname'])){
                                    echo $_SESSION['lastname'];
                                    unset($_SESSION['lastname']);
                                }
                                unset($_SESSION['lastname_input']);
                                ?>
                            </div>
                        </div>

                        <span>Email Address</span>
                        <input type="text" name="email" value="<?php echo $email_input; ?>" required>
                        <?php
                                if(isset($_SESSION['email'])){
                                    echo $_SESSION['email'];
                                    unset($_SESSION['email']);
                                } 
                                unset($_SESSION['email_input']);
                        ?>

                        <span>Password</span>
                        <input type="password" name="password" value="<?php echo $password_input; ?>" required>
                        <?php
                                if(isset($_SESSION['password'])){
                                    echo $_SESSION['password'];
                                    unset($_SESSION['password']);
                                } 
                                unset($_SESSION['password_input']);
                        ?>

                        <span>Confirm Password</span>
                        <input type="password" name="password2" required>
                        <?php
                                if(isset($_SESSION['password2'])){
                                    echo $_SESSION['password2'];
                                    unset($_SESSION['password2']);
                                } 
                        ?>
                        <div class="btn">
                        <p>Already have an account? <a href="login.php">Login</a>
                        </div>
                        <div class="form_btn">
                            <button type="submit" id="submit" name="register">Register</button>
                        </div>
                        
                    </div>
                </form>
            </div>

        </div>
    </div>
</body>
</html>