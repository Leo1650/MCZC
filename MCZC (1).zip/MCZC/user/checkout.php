<?php
include("navbar.php");
include("../fu/db_conn.php");
session_start();


$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($id);



$select_user = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
if(mysqli_num_rows($select_user)){
    $row_user = mysqli_fetch_array($select_user);
    if($row_user['address_home'] != ''){
        $street = $row_user['address_home'];
    }else{
        $street = 'Add';
    }
    if($row_user['address_brgy'] != ''){
        $barangay = $row_user['address_brgy'];
    }else{
        $barangay = 'Add';
    }
    if($row_user['phone'] != ''){
        $phone = $row_user['phone'];
    }else{
        $phone = 'Add';
    }
}

if(isset($_POST['place_order'])){
    $MOD = $_POST['MOD'];
    $quantity = $_POST['total_item'];
    $amount = $_POST['total_amount'];
    $sub_total = $_POST['sub_total'];
    $times_used = 0;

    if($sub_total != $amount){
        $discount = 1;
    }else{
        $discount = 0;
    }

    $order_no = generateKey($mysqli);

    $check_add = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
    
    if(mysqli_num_rows($check_add) != 0){
        $row_check_add = mysqli_fetch_array($check_add);
        $back_up_user_id = $row_check_add['id'];
        if($row_check_add['address_home'] != '' && $row_check_add['address_brgy'] != '' && $row_check_add['phone'] != ''){
            $address = $row_check_add['address_home'] . ' ' . $row_check_add['address_brgy'] . ', Zamboanga City';
            $phone = $row_check_add['phone'];

            if($MOD == 'Paypal'){
                $insert_order = $mysqli->query("INSERT INTO orders (user_id, order_no, mode_of_payment, address, phone, quantity, amount, discount, status, delivery_permission) VALUES ('$user_id', '$order_no', '$MOD', '$address', '$phone', '$quantity', '$amount', '$discount', '0', '0')");
                if($insert_order){
                    $order_no_enc = base64_encode($order_no);
                    header("Location: paypal.php?ui=$id&&on=$order_no_enc");
                }
            }elseif($MOD == 'COD'){
                $insert_order = $mysqli->query("INSERT INTO orders (user_id, order_no, mode_of_payment, address, phone, quantity, amount, discount, status, delivery_permission) VALUES ('$user_id', '$order_no', '$MOD', '$address', '$phone', '$quantity', '$amount', '$discount', '0', '1')");
               
                if($insert_order){
                    
                    $from_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$back_up_user_id'");
                    $count = 0;
                    if(mysqli_num_rows($from_cart) != 0){
                        
                        while($row_from_cart = mysqli_fetch_array($from_cart)){
                            $count += 1;
                            $product_id = $row_from_cart['product_id'];
                            $product_image = $row_from_cart['product_image'];
                            $product_name = $row_from_cart['product_name'];
                            $quantity = $row_from_cart['quantity'];
                            $size = $row_from_cart['size'];

                            $to_order_details = $mysqli->query("INSERT INTO order_details (order_no, product_id, product_image, product_name, quantity, size) VALUES ('$order_no', '$product_id', '$product_image', '$product_name', '$quantity', '$size')");
                            if($to_order_details){
                                $select_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
                                if(mysqli_num_rows($select_product) != 0){
                                    $row_selected = mysqli_fetch_array($select_product);
                                }
                                if($size == 'Regular'){
                                    $new_stock = $row_selected['regular_stock'] - $quantity;
                                    $update_stock = $mysqli->query("UPDATE products SET regular_stock = '$new_stock' WHERE id = '$product_id'");
                                }
    
                                if($size == 'Large'){
                                    $new_stock = $row_selected['large_stock'] - $quantity;
                                    $update_stock = $mysqli->query("UPDATE products SET large_stock = '$new_stock' WHERE id = '$product_id'");
                                }
                                
                                
                            }
                        }
                    }
                    if($count == mysqli_num_rows($from_cart)){
                        $remove_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$back_up_user_id'");
                        if($remove_cart){
                            $order_no_enc = base64_encode($order_no);
                            header("Location: trackOrder.php?ui=$id");
                        }
                    }
                    
                }else{
                    $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='far fa-exclamation-triangle'></i><br>Failed</div>";
                    header("Location: checkout.php?ui=$id");
                    exit();
                }
            }/*elseif($MOD == 'Pick-up'){
                if($sub_total != $amount){   
                    $discount_times_used = $mysqli->query("SELECT * FROM discounts WHERE code = '$discount_code'");
                    if(mysqli_num_rows($discount_times_used) != 0){
                        $row_time = mysqli_fetch_array($discount_times_used);
                        $coupon_use = $row_time['times_used'] + 1;
                        $update_discount_use = $mysqli->query("UPDATE discounts SET times_used = '$coupon_use' WHERE code = '$discount_code' LIMIT 1");
                    }
                }

                $insert_order = $mysqli->query("INSERT INTO orders (user_id, order_no, mode_of_payment, address, phone, quantity, amount, discount, status, delivery_permission) VALUES ('$user_id', '$order_no', '$MOD', '$address', '$phone', '$quantity', '$amount', '$discount', '0', '0')");
                if($insert_order){
                    $order_no_enc = base64_encode($order_no);
                    header("Location: pick_up.php?ui=$id&&on=$order_no_enc");
                }

            }*/
        }else{
            $_SESSION['add_error'] = '<p id="add_error">Please input delivery address and phone number</p>';
            header("Location: checkout.php?ui=$id");
            exit();
        }
    }
    
}elseif(isset($_POST['delivery_add'])){
    $st = $_POST['street'];
    $brgy = $_POST['barangay'];
    $phone = $_POST['phone'];
    

    if(!ctype_digit($phone)){
            $_SESSION['add_error'] = '<p id="add_error">Phone number must be numeric characters</p>';
            header("Location: checkout.php?ui=$id");
            exit();
    }elseif(strlen($phone) < 10){
        $_SESSION['add_error'] = '<p id="add_error">Phone number must 10 digits eg. 955 123 4567</p>';
        header("Location: checkout.php?ui=$id");
        exit();
    }

    $insert_add = $mysqli->query("UPDATE users SET address_home = '$st', address_brgy = '$brgy', phone = '$phone' WHERE id = '$user_id' LIMIT 1");

    if($insert_add){
        
        header("Location: checkout.php?ui=$id");
        exit();
    }
}



//Generate Order no.
function checkKeys($mysqli, $randStr){

    $result = $mysqli->query("SELECT * FROM orders");
    if(mysqli_num_rows($result) != 0){
        while($row = mysqli_fetch_array($result)){
            if($row['order_no'] == $randStr){
                $keyExist = true;
                break;
            }else{
                $keyExist = false;
            }
        }
    }else{
        $keyExist = false;    
    }
    return $keyExist;
}

function generateKey($mysqli){
    $keylength = 11;
    $str = "1234567890";
    $randStr = substr(str_shuffle($str), 0, $keylength);


    $checkKey = checkKeys($mysqli, $randStr);

    while($checkKey == true){
        $randStr = substr(str_shuffle($str), 0, $keylength);
        $checkKey = checkKeys($mysqli, $randStr);
    }

    return $randStr;
}
//End Order no.

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="../css/checkout.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    
<div class="title_section">
    <h3>Checkout</h3>   
</div>


<div class="checkout-wrapper">
<form action="checkout.php?ui=<?php echo $id; ?>" method="POST">

<div class="items-wrapper">
<table>
            
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>

            </tr>
            
            <?php
                $select_my_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
                if(mysqli_num_rows($select_my_cart) != 0){
                    $sub_total = 0;
                    $total = 0;
                    $total_item = 0;
                    while($row_cart = mysqli_fetch_array($select_my_cart)){
                        $total_item += $row_cart['quantity'];
                        $sub_total = $row_cart['price'] * $row_cart['quantity'];
                        $pid = base64_encode($row_cart['product_id']);
                        echo '<tr id="input"> 
                        
                        <td>
                           <div class="cart-info"> 
                                <img src="../admin/products_img/'.$row_cart['product_image'].'" >
                                <div>
                                    <p>'.$row_cart['product_name'].'</p>
                                    <small><i>'.$row_cart['size'].'</i></small>
                                    <br>
                                </div>
                           </div>
                        </td>
                     
                        <td><span>&#8369</span> '.$row_cart['price'].'</td>
                        <td>x'.$row_cart['quantity'].'</td>
                        <td><span>&#8369</span> '.number_format($sub_total, 2).'</td>
                        </tr>';

                        $total += $sub_total;
                    }
                }else{
                    $total_item = 0;
                    $total = 0;
                }
            ?>
                    
        </table>
</div>


<br>
    <div class="address-payment-wrapper">
        <div class="address">
        <table id="add" >    
                    <tr>  
                        <td style="text-align: left;"><strong>Delivery Address</strong></td>
                        <td></td>
                    
                    </tr>

                    <tr>
                    <td >Street: <?php echo $street; ?></td>
                    
                    <td class=td1> <a class="button" onclick="show_add_form()"><b>Edit</b></a>&nbsp;&nbsp;</td>
                    </tr>

                    <tr>
                    <td >Barangay: <?php echo $barangay; ?></td>
                    <td></td>
                    </tr>

                    <tr>
                    <td >City: Zamboanga City</td>
                    <td></td>
                    </tr>

                    <tr>
                    <td ->Contact: +63 <?php echo $phone; ?></td>
                    <td class=td1></td>
                    </tr>
                    <tr>
                        <td><?php
                                if(isset($_SESSION['add_error'])){
                                    echo $_SESSION['add_error'];
                                    //unset($_SESSION['add_error']);
                                    session_destroy();
                                }
                            ?></td>
                    </tr>
                
                </table>

        </div>
        <br>
        <div class="payment">
        <table id="mod" >
                        
                        <tr>
                            <td style="text-align: left;" ><strong>Payment Option</strong></td>
                        </tr>
                            <tr><td></td></tr>
                            <tr><td></td></tr>
                            <tr><td></td></tr>
                            
                        <tr>
                            <td class=td1><input type="radio" name="MOD" id="COD" value="COD" checked ><label for="COD">Cash on Delivery</label></td>
                    
                        </tr>

                        <tr>
                            <td id="paypaltd"><input type="radio" name="MOD" value="Paypal" id="paypal"><label for="paypal"><i class="fab fa-paypal"></i>aypal</label></td>
                        </tr>
                        <tr><td></td></tr>
                        <tr><td></td></tr>

            </table>
        </div>   
    </div>

    <br>

    <div class="placeorder-wrapper">        
        <br>
        <table id="placeorder">
        
            <tr>
        
                <td >Items Subtotal</td>
                <td><span>&#8369</span> <?php echo number_format($total, 2); ?></td>
                
            </tr>
            
            <input type="hidden" id="sub_total" name="sub_total" value="<?php echo $total; ?>" >

            <tr>
                <td>Total Items</td>
                <td id="qty">x<?php echo $total_item; ?></td>    
                <input type="hidden" id="total_item" name="total_item" value="<?php echo $total_item; ?>" >
                <td > 
                    <button type="submit" class="button1" id="place_order" name="place_order"><b>Place Order</b></button>
                </td>
            </tr>
        

            <tr style="font-size: 20px;">
                <td ><b>Total Payment</b></td>
                <td id="tot_pay"><span>&#8369</span> <?php echo number_format($total, 2); ?></td>
                <input type="hidden" id="total_amount" name="total_amount" value="<?php echo $total; ?>" >
                
            </tr>     
            
            <tr>
            

                </tr>
        </table>
    </div>
</form>   

</div>


        
            
                       
                   

 <!--Add Delivery Address-->
 <div class="form-overlay" id="add_delivery_address">
            <div class="form-wrapper">
                <div class="formbox">
                    <div class="banner">
                         <span id="form_title">Edit Delivery Address</span>
                        <div class="cancel" onclick="hide_add_form()"><i class="fas fa-times fa-lg fa-fw"></i></div>
                    </div>
                   
                    <form action="checkout.php?ui=<?php echo $id; ?>" method="POST">
                        <div class="form-control">
                            
                            <div class="first_col">
                                <span>Street:</span>
                                <input type="text" placeholder="House No./Street" class="input" required name="street">

                                
                                <span>Barangay:</span>
                                <input type="text" placeholder="Barangay" class="input" required name="barangay">

                                <span>Contact:</span>
                                <input type="text" placeholder="+63" class="input" required name="phone">
                            </div>

                            <div class="second_col">
                                <div class="action-btn">
                                    <input type="submit" value="Save" id="create" name="delivery_add">
                                </div>
                            </div>
                           
                        </div>
                    </form>
                </div>
            </div>
</div>


<!--Add Coupon Code
<div class="form-overlay" id="add_coupon_code">
            <div class="form-wrapper">
                <div class="formbox">
                    <div class="banner"> 
                        <div class="cancel" onclick="hide_coupon()"><i class="fas fa-times fa-lg fa-fw"></i></div>
                    </div>
                    <span id="form_title">Discount</span>
                    <form action="checkout.php?ui=<?php #echo $id; ?>" method="POST">
                        <div class="form-control">
                            
                            <div class="first_col">
                                <span>Coupon Code:</span>
                                <input type="text" placeholder="Coupon Code" class="input" required name="coupon_code">
                                <input type="hidden" name="product_id" value="<?php #echo $pid; ?>">
                                <input type="hidden" id="total_amount_for_coupon" name="tot_amount" value="<?php #echo $total; ?>" >
                                <input type="hidden" id="sub_total_for_coupon" name="sub_tot" value="<?php #echo $sub_total; ?>" >

                            <div class="second_col">
                                <div class="action-btn">
                                    <input type="submit" value="Apply" id="create" name="coupon">
                                </div>
                            </div>
                           
                        </div>
                    </form>
                </div>
            </div>
</div>
-->

        </div>
        <?php 
            if(isset($_SESSION['cart_feedback'])){
                echo $_SESSION['cart_feedback'];
                unset($_SESSION['cart_feedback']);
            }
        ?>


    <script>
        var add_delivery_address = document.getElementById('add_delivery_address');

        function show_add_form(){
            add_delivery_address.style.display = "block";
        }
        function hide_add_form(){
            add_delivery_address.style.display = "none";
        }
    </script>
    <script>
        $(document).ready(function(){
            $("#coupon_code").click(function(e){
                e.preventDefault();
            })
        });
            var add_coupon_code = document.getElementById('add_coupon_code');

            function show_coupon(){
                add_coupon_code.style.display = "block";
            }
            function hide_coupon(){
                add_coupon_code.style.display = "none";
            }
        </script>
</body>
</html>
<?php
include("footer.php");
?>
