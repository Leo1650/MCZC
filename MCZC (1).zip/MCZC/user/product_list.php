<?php
include("navbar.php");
include("../fu/db_conn.php");


$cid =mysqli_real_escape_string($mysqli, $_GET['cid']);
$ui =mysqli_real_escape_string($mysqli, $_GET['ui']);
$c_id = base64_decode($cid);
$user_id = base64_decode($ui);

if($c_id == 0){
    $cat_name = 'All Products';
}else{
    $select_cat_name = $mysqli->query("SELECT * FROM categories WHERE id = '$c_id'");
    $row_cat_name = mysqli_fetch_array($select_cat_name);
    $cat_name = $row_cat_name['name'];    
}

if(isset($_POST['add_to_cart'])){
    $product_id = $_POST['product_id'];
    $category_id = $_POST['category_id'];
    $image = $_POST['image'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $size = $_POST['size'];

    $check_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
    if(mysqli_num_rows($check_product) != 0){
        $row_product = mysqli_fetch_array($check_product);
        if($size == 'Regular'){
            if($row_product['regular_stock'] == 0){
                header("Location: product_list.php?ui=$ui&&cid=$cid");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>".$size." ".$row_product['name']." is Out of Stock</div>";
                exit();
            }
        }
    }
    


    $check_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id' AND product_id = '$product_id' AND size = '$size' ");
    if(mysqli_num_rows($check_cart) != 0){
        $row_cart_check = mysqli_fetch_array($check_cart);
        $quantity = $row_cart_check['quantity'] + 1;
        $update_product_qty = $mysqli->query("UPDATE cart SET quantity = '$quantity' WHERE product_id = '$product_id' AND size = '$size'");

        if($update_product_qty){
            header("Location: product_list.php?ui=$ui&&cid=$cid");
            $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check'></i><br> Product has been added to your cart</div>";
            exit();
        }
    }else{
        $insert_to_cart = $mysqli->query("INSERT INTO cart (user_id, product_id, category_id, product_image, product_name, price, size, quantity) VALUES ('$user_id', '$product_id', '$category_id', '$image', '$name', '$price', '$size', '1')");

        if($insert_to_cart){
            header("Location: product_list.php?ui=$ui&&cid=$cid");
            $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check'></i><br> Product has been added to your cart</div>";
            exit();
        }
    }

  
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/product_list.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Products</title>
</head>
<body>
    <div class="container">
        <div class="select_category_section">
            <h1>Cathegory</h1>
            <h3><?php echo $cat_name; ?></h3>

            <select name="category" id="category">
                
                <?php     
                    if($c_id != 0){
                        $selected_category = $mysqli->query("SELECT * FROM categories WHERE id = '$c_id'");
                        $row_selected_cat = mysqli_fetch_array($selected_category);
                        echo '<option value="'.$row_selected_cat['id'].'">'.$row_selected_cat['name'].'</option>';
                        $query = 'WHERE category = '.$c_id.'';
                    }else{
                        echo '<option value="0">All Products</option>';
                        $query = '';
                    }
                    $all_category = $mysqli->query("SELECT * FROM categories");
                    if(mysqli_num_rows($all_category) != 0){
                        while($row_all_cat = mysqli_fetch_array($all_category)){
        
                            if($c_id != $row_all_cat['id']){
                                echo '<option value="'.$row_all_cat['id'].'">'.$row_all_cat['name'].'</option>';
                            }
                        }
                        if($c_id != 0){
                            echo '<option value="0">All Products</option>';
                        }
                    }else{
                        echo '<option value="">Please Create Category</option>';
                    }
                ?>
            </select>
        </div>
        <div class="best_seller_section">
            <div class="best_seller_body">
                <div class="all_product_wrapper">

                <?php
                    $select_featured_product = $mysqli->query("SELECT * FROM products $query");
                    if(mysqli_num_rows($select_featured_product) != 0){ 
                        $default_size = base64_encode('Regular');
                        while($row_featured = mysqli_fetch_array($select_featured_product)){
                            $item_id = base64_encode($row_featured['id']);
                            echo '<div class="product_wrapper">
                                <div class="product_control">
                            <form action="product_list.php?ui='.$ui.'&&cid='.$cid.'" method="POST">
                                    <a href="item_page.php?ui='.$ui.'&&pid='.$item_id.'&&se='.$default_size.'"><div class="product_img"><img src="../admin/products_img/'.$row_featured['image'].'" alt="Product Picture"></div></a>
                                    <div class="details">
                                    <div class="product_name">'.$row_featured['name'].'</div> 
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].'</div>
                
                                <br/>
                                    <input type="hidden" value="'.$row_featured['id'].'" name="product_id">
                                    <input type="hidden" value="'.$row_featured['category'].'" name="category_id">
                                    <input type="hidden" value="'.$row_featured['name'].'" name="name">
                                    <input type="hidden" value="'.$row_featured['image'].'" name="image">
                                    <input type="hidden" value="'.$row_featured['regular_price'].'" name="price">
                                    <input type="hidden" value="Regular" name="size">
                                    <div class="product_btn"><a href="item_page.php?ui='.$ui.'&&pid='.$item_id.'&&se='.$default_size.'">Buy Now</a></div>
                                    </div>
                            </form>
                                </div>
                            </div>';
                            
                        }
                    }else{
                        echo '<div class="container_err">
                            <div class="progress">
                                <p>No Products</p>
                            </div>
                            </div>
                            ';
                    }

                ?>           

                </div>
            </div>
        </div>

    </div>



        <?php 
            if(isset($_SESSION['cart_feedback'])){
                echo $_SESSION['cart_feedback'];
                unset($_SESSION['cart_feedback']);
            }
        ?>


    <script>
        var param = new URLSearchParams(window.location.search);
        var ui = param.get('ui');
        var cid = param.get('cid');

        var selected = document.getElementById("category");        
        category.addEventListener("change", function(){
            cid = btoa(selected.value)
            window.location.href = "product_list.php?ui="+ui+"&&cid="+cid+"";
            
        });
    </script>
</body>
</html>

<?php
include("footer.php");
?>
