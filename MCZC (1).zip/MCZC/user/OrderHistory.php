<?php
include("navbar.php");
include("../fu/db_conn.php");

$ui =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($ui);

if(isset($_GET['on'])){
    $on =mysqli_real_escape_string($mysqli, $_GET['on']);
    $update_order = $mysqli->query("SELECT * FROM orders WHERE order_no = '$on'");
    if(mysqli_num_rows($update_order) != 0){
        $row_update_order = mysqli_fetch_array($update_order);
    }
    echo ' <div class="form-overlay" id="update_status">
    <div class="form-wrapper">
        <div class="formbox">
                <div class="form-control">
                    <div class="first_col">
                        <span class="label"><i class="fas fa-tags"></i>&nbsp;Items:</span><br><br>
                            <div id="items_container">
                                    <ul class="label">';
                                $total_items = 0;
                                $order_details = $mysqli->query("SELECT * FROM order_details WHERE order_no = '$on'");
                                if(mysqli_num_rows($order_details) != 0){
                                    while($orders = mysqli_fetch_array($order_details)){
                                        echo '
                                        <li id="details">
                                            <div class="items">
                                                <img src="../admin/products_img/'.$orders["product_image"].'" alt="">
                                                <div class="item_control">
                                                    <span class="item_label">'.$orders["product_name"].'</span>
                                                    <span class="item_label">x'.$orders["quantity"].'</span>
                                                    <span class="item_label">'.$orders["size"].'</span>
                                                </div>
                                            </div>
                                        </li><br>
                                        ';

                                    }
                                }
         
                                    echo '</ul>
                            </div><br>
                              
                        </div><br>
                         <a href="OrderHistory.php?ui='.$ui.'" class="button" id="close">Close</a>
                </div>
        </div>
    </div>
</div>';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order History</title>
  <link rel="stylesheet" href="../css/OrderHistory.css">
  <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
  <script src="https://kit.fontawesome.com/ed284aa2e1.js" crossorigin="anonymous"></script>

</head>

<body>
  <div class="container_wrapper">
    
        
            <?php

                $select_history = $mysqli->query("SELECT * FROM orders WHERE user_id = '$user_id' AND status = '3' ");
                if(mysqli_num_rows($select_history) != 0){
                    while($row_history = mysqli_fetch_array($select_history)){
                        echo '<div class="container">
                        <div class="details-wrapper">
                        <h1 ><i class="fas fa-history"></i>&nbsp;Order History</h1>
                        <p><i>Order I.D.: '.$row_history['order_no'].'</i></p>
                        <p><i>Date&Time: '.$row_history['date_ordered'].'</i></p>
                        <p><i>Items Qty: x'.$row_history['quantity'].'</i></p>
                        <p><i>Amount: '.$row_history['amount'].'</i></p>                   
                        <br>
                        <p><i>Status: Delivered</i></p>
                        <a href="OrderHistory.php?ui='.$ui.'&&on='.$row_history['order_no'].'" class="button">View Items</a>

                        </div>
                        </div>';


                        
                }
                }else{
                    echo ' <div class="no-orders">
                    <p>No Orders.</p>
                    </div>';
                }
            ?>
            

</div>
</body>
</html>
<?php
include("footer.php");
?>
