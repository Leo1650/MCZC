<?php
include("navbar.php");
include("../fu/db_conn.php");
session_start();

$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($id);


if(isset($_POST['qty'])){
    $qty = $_POST['qty'];
    $cid = $_POST['cid'];
    $p_price = $_POST['p_price'];
    $pid = $_POST['pid'];
    $size = $_POST['size'];

   
    $stmt = $mysqli->prepare("UPDATE cart SET quantity=? WHERE id =?");
    $stmt->bind_param("ii", $qty,$cid);
    $stmt->execute();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="../css/cart.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    
<div class="title_section">
    <h3>My Cart</h3>   
</div>

<div class="cart-wrapper">
    <div class="item-wrapper">
        
    <table>
                <tr>
                <th>Item</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Remove</th>
                </tr>
       
                <?php
                $select_my_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
                if(mysqli_num_rows($select_my_cart) != 0){
                    $total_item = 0;
                    $sub_total = 0;
                    $total = 0;

                    while($row_cart = mysqli_fetch_array($select_my_cart)){
                        $default_size = base64_encode($row_cart['size']);

                        $product_id = $row_cart['product_id'];
                        $selected_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
                        $row_product = mysqli_fetch_array($selected_product);
                        if($row_cart['size'] == 'Regular'){
                            $stock = $row_product['regular_stock'];
                        }elseif($row_cart['size'] == 'Large'){
                            $stock = $row_product['large_stock'];
                        }

                        $total_item += $row_cart['quantity'];
                        $sub_total = $row_cart['price'] * $row_cart['quantity'];
                        $pid = base64_encode($row_cart['product_id']);
                        echo '<tr> 
                        <input type="hidden" class="size" value="'.$row_cart['size'].'">
                        <input type="hidden" class="pid" value="'.$row_cart['product_id'].'">
                        <input type="hidden" class="cid" value="'.$row_cart['id'].'">
                        <td>
                           <div class="cart-info"> 
                                    <a href="item_page.php?ui='.$id.'&&pid='.$pid.'&&se='.$default_size.'"><img src="../admin/products_img/'.$row_cart['product_image'].'" ></a>
                                <div>
                                    <p>'.$row_cart['product_name'].'</p>
                                    <small><i>'.$row_cart['size'].'</i></small><br>
                                    <small><i>Stock: '.$stock.'</i></small>
                                    <br>
                                    
                                </div>
                           </div>
                        </td>
                        <input type="hidden" class="p_price" value="'.$row_cart['price'].'">
                        <td><span>&#8369</span> '.$row_cart['price'].'</td>
                        <td><input type="number" value="'.$row_cart['quantity'].'" min="1" max="'.$stock.'" class="itemQty"></td>
    

                        <td>
                            <div class="delete-button">
                            <a href="../fu/delete_cart_item.php?ui='.$id.'&&cart_id='.$row_cart['id'].'" onclick=\'javascript: return confirm("Are you sure?");\'><i class="fas fa-trash"></i></a>
                            </div>
                        </td>
                        
                        </tr>';

                        

                        $total += $sub_total;
                        $disabled = '';
                        $style = '';
                    }

                    
                }else{
                    $disabled = 'disabled';
                    $style = 'style = "background-color: #777; pointer-events: none;"';
                    $total_item = 0;
                    $total = 0;
                    echo '<tr>
                    <td colspan=4 id="noItem">
                    No Items!
                    </td>
                    </tr>';
                }
            ?>
         </table>

    </div>
            </br>
    <div class="checkout-wrapper">
            <table >             
                <tr>
                    <td >Total Items</td>
                    <td>x<?php echo $total_item; ?></td>
                    <?php
                        if(!isset($_SESSION['guessID'])){
                    ?>
                            <td colspan="2"><a href="checkout.php?ui=<?php echo $id; ?>" class="button1" <?php echo $style; echo ' '.$disabled.''; ?>><b>Checkout</b></a></td>
                    <?php
                        }else{
                    ?>
                            <td colspan="2"><a href="login.php" class="button1" <?php echo $style; echo ' '.$disabled.''; ?>><b>Checkout</b></a></td>
                    <?php
                        }
                    ?>

                </tr>

                <tr>
                    <td>Total Price</td>
                    <td><span>&#8369</span> <?php echo number_format($total, 2); ?></td>
                    <td></td>
                </tr>
                 
            </table>


    </div>

</div>





    
       
        <?php 
            if(isset($_SESSION['cart_feedback'])){
                echo $_SESSION['cart_feedback'];
                unset($_SESSION['cart_feedback']);
            }


            //header("Location: checkout.php?ui=$id");

            //echo '<script>window.location = "checkout.php?ui='.$id.'"</script>';
        ?>

        
 
        <script>
            $(".itemQty").on('change', function(){
                var $el = $(this).closest('tr');
                var cid = $el.find('.cid').val();
                var pid = $el.find('.pid').val();
                var size = $el.find('.size').val();
                var p_price = $el.find('.p_price').val();
                var qty = $el.find('.itemQty').val();

                console.log(size);


                if(qty == 0 || isNaN(qty)){
                    qty = 1;
                }
                location.reload(true);
                var param = new URLSearchParams(window.location.search);
                var ui = param.get('ui');
                $.ajax({
                   url: 'cart.php?ui='+ui+'',
                   method: 'POST',
                   cache: false,
                   data: {qty:qty,cid:cid,p_price:p_price,pid:pid,size:size},
                   success: function(response){ 
                       console.log(response);
                   } 
                });

            });
        </script>

        


</body>
</html>
<?php
include("footer.php");
?>

