<?php
include("../fu/db_conn.php");

$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$on =mysqli_real_escape_string($mysqli, $_GET['on']);
$user_id = base64_decode($id);
$order_no = base64_decode($on);

$select_order = $mysqli->query("SELECT * FROM orders WHERE user_id = '$user_id' AND order_no = '$order_no' ");
if(mysqli_num_rows($select_order) != 0){
    $row_order = mysqli_fetch_array($select_order);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/checkout.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title>Paypal Payment</title>
</head>
<body style="background-color:#df313c">
    <div class="container">
        <div class="form_control">
            <h1 style="text-align: center; font-size:15pt;">You are about to pay</h1>
            <span  style="text-align: center;"><p class="p">&#8369 <?php echo $row_order['amount']; ?></p></span>
            <input type="hidden" value="<?php echo $row_order['amount']; ?>" id="total_amount">
            <span  style="text-align: center;">Click the button below to continue. </span>
            <div id="paypal-button-container">
        </div>
        
    </div>

<script
    src="https://www.paypal.com/sdk/js?client-id=AY-obt4iIYKuvPu91GadYaPtnbEHKw21GW2AsLEByq-NlqC7UQGnjG2K9NGevTfA4jiIFZiFoerDUtt4&disable-funding=credit,card">
  </script>

  <div id="paypal-button-container"></div>

  <script>
    var param = new URLSearchParams(window.location.search);
    var ui = param.get('ui');
    var on = param.get('on');

    var total_amount = document.getElementById('total_amount');
    var price = String(total_amount.value);
    paypal.Buttons({
    style:{
        color:"blue",
        shape:"pill"
    },
    createOrder:function(data,actions){
        return actions.order.create({
            purchase_units:[{
                amount:{
                    value:price
                }
            }]
         
        });
    },
    onApprove:function(data,actions){
        return actions.order.capture().then(function(details){
            console.log(details)
            window.location.replace('http://meryendacraves.store/user/paypal_payment_approve.php?ui='+ui+'&&on='+on+'')
       
        })
    },
    onCancel:function(data){
        window.location.replace('http://meryendacraves.store/user/checkout.php?ui='+ui+'&&on='+on+'')
    }
}).render('#paypal-button-container');

  </script>
</body>
</html>