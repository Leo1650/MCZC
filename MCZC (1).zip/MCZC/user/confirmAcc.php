<?php
include("../fu/db_conn.php");
$vkey =mysqli_real_escape_string($mysqli, $_GET['vkey']);
?>
<!DOCTYPE html>
<html>

<head>
    <title>Confirmation</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <link rel="stylesheet" href="../css/confirm.css">
</head>

<body>


<div class="form-wrapper">
    <div class="formbox">
        <div class="form">
            <div class="img-wrapper">
            <img src="../img/MCLogo.png" alt="Logo">
            </div>

            <div class="header-wrapper">
            <h1>Welcome!</h1>
            <p>Please click the button below to continue.</p>
            </div>
            

            <div class="button-wrapper">
            <a href="verify.php?vkey=<?php echo $vkey; ?>" id="button">Confirm Account</a>
            </div>
        </div>
    </div>
</div>
   
</body>

</html>